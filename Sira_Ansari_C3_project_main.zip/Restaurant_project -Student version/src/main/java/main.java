import java.time.LocalTime;
import java.util.Arrays;
import java.util.Collections;

public class main {
    public static void main(String[] args) throws restaurantNotFoundException {
        Restaurant rs1 = new Restaurant("ABC","Mumbai",LocalTime.of(10,30),LocalTime.of(23,00));

        rs1.addToMenu("a",10);
        rs1.addToMenu("b",20);
        rs1.addToMenu("c",30);

        System.out.println(rs1.getOrderValue(Arrays.asList("a", "b")));
    }


}