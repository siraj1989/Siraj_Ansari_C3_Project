import java.util.ArrayList;

public class Item {
    private String name;
    private int price;

    private static ArrayList<Item> menu;

    public Item(String name, int price) {
        this.name = name;
        this.price = price;
    }

    public static void setMenu(ArrayList<Item> newMenu) {
        menu = newMenu;
    }

    public static int getOrderValue(ArrayList<String> itemNames) {
        int total = 0;
        for (String itemName : itemNames) {
            for (Item item : menu) {
                if (item.getName().equals(itemName)) {
                    total += item.getPrice();
                    break;
                }
            }
        }
        return total;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return name + ":" + price;
    }
}
